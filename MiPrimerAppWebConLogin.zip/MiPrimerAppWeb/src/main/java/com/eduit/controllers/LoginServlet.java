package com.eduit.controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String emailId = request.getParameter("emailId");
		String password = request.getParameter("password");

		System.out.println("llego al back end el emailId : " + emailId);
		System.out.println("llego al back end el password : " + password);

		//de tarea crear :
//		1- Tabla "USERS" en la bd mySql donde se guarden los usuario y sus claves
//		2- Crear UserVO para mapear la talba del punto 1
//		3- Crear UserDAO para poder realizar el CRUD contra el UserVO y la tabla "USERS"		
//		4- utilizar el UserDAO dentro del metodo  doPost() del la clase Loginservlet.java
		
		if(emailId != null && emailId.equalsIgnoreCase("admin@gmail.com") && emailId != null && password.equalsIgnoreCase("admin"))
		{
//			redirigimos a una pagina de bienvenida y pasamos datos en la session
			HttpSession httpSession = request.getSession();
			//seteamos en la session el emailId
			httpSession.setAttribute("emailId",emailId);
			
			//redirecciono a otra pagina
			//request.getRequestDispatcher("index.html").forward(request, response);
			request.getRequestDispatcher("welcome.jsp").forward(request, response);
			
		}
		
		//doGet(request, response);
	}

}
